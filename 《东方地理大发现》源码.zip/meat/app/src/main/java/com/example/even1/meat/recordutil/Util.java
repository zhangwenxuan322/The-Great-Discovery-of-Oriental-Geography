package com.example.even1.meat.recordutil;

import android.content.Context;

import com.amap.api.location.AMapLocation;
import com.amap.api.maps.model.LatLng;
import com.amap.api.trace.TraceLocation;
import com.example.even1.meat.R;

import java.util.ArrayList;
import java.util.List;
public class Util {
	/**
	 * 将AMapLocation List 转为TraceLocation list
	 * 
	 * @param list
	 * @return
	 */
	public static List<TraceLocation> parseTraceLocationList(
			List<AMapLocation> list) {
		List<TraceLocation> traceList = new ArrayList<TraceLocation>();
		if (list == null) {
			return traceList;
		}
		for (int i = 0; i < list.size(); i++) {
			TraceLocation location = new TraceLocation();
			AMapLocation amapLocation = list.get(i);
			location.setBearing(amapLocation.getBearing());
			location.setLatitude(amapLocation.getLatitude());
			location.setLongitude(amapLocation.getLongitude());
			location.setSpeed(amapLocation.getSpeed());
			location.setTime(amapLocation.getTime());
			traceList.add(location);
		}
		return traceList;
	}

	/**
	 * 将AMapLocation List 转为LatLng list
	 * @param list
	 * @return
	 */
	public static List<LatLng> parseLatLngList(List<AMapLocation> list) {
		List<LatLng> traceList = new ArrayList<LatLng>();
		if (list == null) {
			return traceList;
		}
		for (int i = 0; i < list.size(); i++) {
			AMapLocation loc = list.get(i);
			double lat = loc.getLatitude();
			double lng = loc.getLongitude();
			LatLng latlng = new LatLng(lat, lng);
			traceList.add(latlng);
		}
		return traceList;
	}
	
	public static AMapLocation parseLocation(String latLonStr) {
		if (latLonStr == null || latLonStr.equals("") || latLonStr.equals("[]")) {
			return null;
		}
		String[] loc = latLonStr.split(",");
		AMapLocation location = null;
		if (loc.length == 6) {
			location = new AMapLocation(loc[2]);
			location.setProvider(loc[2]);
			location.setLatitude(Double.parseDouble(loc[0]));
			location.setLongitude(Double.parseDouble(loc[1]));
			location.setTime(Long.parseLong(loc[3]));
			location.setSpeed(Float.parseFloat(loc[4]));
			location.setBearing(Float.parseFloat(loc[5]));
		}else if(loc.length == 2){
			location = new AMapLocation("gps");
			location.setLatitude(Double.parseDouble(loc[0]));
			location.setLongitude(Double.parseDouble(loc[1]));
		}
		
		return location;
	}
	
	public static ArrayList<AMapLocation> parseLocations(String latLonStr) {
		ArrayList<AMapLocation> locations = new ArrayList<AMapLocation>();
		String[] latLonStrs = latLonStr.split(";");
		for (int i = 0; i < latLonStrs.length; i++) {
			AMapLocation location = Util.parseLocation(latLonStrs[i]);
			if (location != null) {
				locations.add(location);
			}
		}
		return locations;
	}

	public static List<Integer> getColorList(int cnt, Context mContext){
		List<Integer> colorList = new ArrayList<Integer>();


		for(int i=0;i<cnt;i++){
			colorList.add(mContext.getResources().getColor(R.color.track_line_1));
			colorList.add(mContext.getResources().getColor(R.color.track_line_1));
			colorList.add(mContext.getResources().getColor(R.color.track_line_2));
			colorList.add(mContext.getResources().getColor(R.color.track_line_2));
			colorList.add(mContext.getResources().getColor(R.color.track_line_3));
			colorList.add(mContext.getResources().getColor(R.color.track_line_3));
			colorList.add(mContext.getResources().getColor(R.color.track_line_4));
			colorList.add(mContext.getResources().getColor(R.color.track_line_4));
			colorList.add(mContext.getResources().getColor (R.color.track_line_5));
			colorList.add(mContext.getResources().getColor (R.color.track_line_5));
			colorList.add(mContext.getResources().getColor (R.color.track_line_6));
			colorList.add(mContext.getResources().getColor (R.color.track_line_6));
			colorList.add(mContext.getResources().getColor (R.color.track_line_7));
			colorList.add(mContext.getResources().getColor (R.color.track_line_7));
			colorList.add(mContext.getResources().getColor (R.color.track_line_8));
			colorList.add(mContext.getResources().getColor (R.color.track_line_8));
			colorList.add(mContext.getResources().getColor (R.color.track_line_9));
			colorList.add(mContext.getResources().getColor (R.color.track_line_9));
			colorList.add(mContext.getResources().getColor (R.color.track_line_10));
			colorList.add(mContext.getResources().getColor (R.color.track_line_10));

			colorList.add(mContext.getResources().getColor (R.color.track_line_11));
			colorList.add(mContext.getResources().getColor (R.color.track_line_11));
			colorList.add(mContext.getResources().getColor (R.color.track_line_12));
			colorList.add(mContext.getResources().getColor (R.color.track_line_12));
			colorList.add(mContext.getResources().getColor (R.color.track_line_13));
			colorList.add(mContext.getResources().getColor (R.color.track_line_13));
			colorList.add(mContext.getResources().getColor (R.color.track_line_14));
			colorList.add(mContext.getResources().getColor (R.color.track_line_14));
			colorList.add(mContext.getResources().getColor (R.color.track_line_15));
			colorList.add(mContext.getResources().getColor (R.color.track_line_15));
			colorList.add(mContext.getResources().getColor (R.color.track_line_16));
			colorList.add(mContext.getResources().getColor (R.color.track_line_16));
			colorList.add(mContext.getResources().getColor (R.color.track_line_17));
			colorList.add(mContext.getResources().getColor (R.color.track_line_17));
			colorList.add(mContext.getResources().getColor (R.color.track_line_18));
			colorList.add(mContext.getResources().getColor (R.color.track_line_18));
			colorList.add(mContext.getResources().getColor (R.color.track_line_19));
			colorList.add(mContext.getResources().getColor (R.color.track_line_19));
			colorList.add(mContext.getResources().getColor (R.color.track_line_20));
			colorList.add(mContext.getResources().getColor (R.color.track_line_20));

			colorList.add(mContext.getResources().getColor (R.color.track_line_21));
			colorList.add(mContext.getResources().getColor (R.color.track_line_21));
			colorList.add(mContext.getResources().getColor (R.color.track_line_22));
			colorList.add(mContext.getResources().getColor (R.color.track_line_22));
			colorList.add(mContext.getResources().getColor (R.color.track_line_23));
			colorList.add(mContext.getResources().getColor (R.color.track_line_23));
			colorList.add(mContext.getResources().getColor (R.color.track_line_24));
			colorList.add(mContext.getResources().getColor (R.color.track_line_24));
			colorList.add(mContext.getResources().getColor (R.color.track_line_25));
			colorList.add(mContext.getResources().getColor (R.color.track_line_25));
			colorList.add(mContext.getResources().getColor (R.color.track_line_26));
			colorList.add(mContext.getResources().getColor (R.color.track_line_26));
			colorList.add(mContext.getResources().getColor (R.color.track_line_27));
			colorList.add(mContext.getResources().getColor (R.color.track_line_27));
			colorList.add(mContext.getResources().getColor (R.color.track_line_28));
			colorList.add(mContext.getResources().getColor (R.color.track_line_28));
			colorList.add(mContext.getResources().getColor (R.color.track_line_29));
			colorList.add(mContext.getResources().getColor (R.color.track_line_29));
			colorList.add(mContext.getResources().getColor (R.color.track_line_30));
			colorList.add(mContext.getResources().getColor (R.color.track_line_30));

			colorList.add(mContext.getResources().getColor (R.color.track_line_31));
			colorList.add(mContext.getResources().getColor (R.color.track_line_31));
			colorList.add(mContext.getResources().getColor (R.color.track_line_32));
			colorList.add(mContext.getResources().getColor (R.color.track_line_32));
			colorList.add(mContext.getResources().getColor (R.color.track_line_33));
			colorList.add(mContext.getResources().getColor (R.color.track_line_33));
			colorList.add(mContext.getResources().getColor (R.color.track_line_34));
			colorList.add(mContext.getResources().getColor (R.color.track_line_34));
			colorList.add(mContext.getResources().getColor (R.color.track_line_35));
			colorList.add(mContext.getResources().getColor (R.color.track_line_35));
			colorList.add(mContext.getResources().getColor (R.color.track_line_36));
			colorList.add(mContext.getResources().getColor (R.color.track_line_36));
			colorList.add(mContext.getResources().getColor (R.color.track_line_37));
			colorList.add(mContext.getResources().getColor (R.color.track_line_37));
			colorList.add(mContext.getResources().getColor (R.color.track_line_38));
			colorList.add(mContext.getResources().getColor (R.color.track_line_38));
			colorList.add(mContext.getResources().getColor (R.color.track_line_39));
			colorList.add(mContext.getResources().getColor (R.color.track_line_39));
			colorList.add(mContext.getResources().getColor (R.color.track_line_40));
			colorList.add(mContext.getResources().getColor (R.color.track_line_40));

			colorList.add(mContext.getResources().getColor (R.color.track_line_41));
			colorList.add(mContext.getResources().getColor (R.color.track_line_41));
			colorList.add(mContext.getResources().getColor (R.color.track_line_42));
			colorList.add(mContext.getResources().getColor (R.color.track_line_42));
			colorList.add(mContext.getResources().getColor (R.color.track_line_43));
			colorList.add(mContext.getResources().getColor (R.color.track_line_43));
			colorList.add(mContext.getResources().getColor (R.color.track_line_44));
			colorList.add(mContext.getResources().getColor (R.color.track_line_44));
			colorList.add(mContext.getResources().getColor (R.color.track_line_45));
			colorList.add(mContext.getResources().getColor (R.color.track_line_45));
			colorList.add(mContext.getResources().getColor (R.color.track_line_46));
			colorList.add(mContext.getResources().getColor (R.color.track_line_46));
			colorList.add(mContext.getResources().getColor (R.color.track_line_47));
			colorList.add(mContext.getResources().getColor (R.color.track_line_47));
			colorList.add(mContext.getResources().getColor (R.color.track_line_48));
			colorList.add(mContext.getResources().getColor (R.color.track_line_48));
			colorList.add(mContext.getResources().getColor (R.color.track_line_49));
			colorList.add(mContext.getResources().getColor (R.color.track_line_49));
			colorList.add(mContext.getResources().getColor (R.color.track_line_50));
			colorList.add(mContext.getResources().getColor (R.color.track_line_50));

			colorList.add(mContext.getResources().getColor (R.color.track_line_51));
			colorList.add(mContext.getResources().getColor (R.color.track_line_51));
			colorList.add(mContext.getResources().getColor (R.color.track_line_52));
			colorList.add(mContext.getResources().getColor (R.color.track_line_52));
			colorList.add(mContext.getResources().getColor (R.color.track_line_53));
			colorList.add(mContext.getResources().getColor (R.color.track_line_53));
			colorList.add(mContext.getResources().getColor (R.color.track_line_54));
			colorList.add(mContext.getResources().getColor (R.color.track_line_54));
			colorList.add(mContext.getResources().getColor (R.color.track_line_55));
			colorList.add(mContext.getResources().getColor (R.color.track_line_55));
			colorList.add(mContext.getResources().getColor (R.color.track_line_56));
			colorList.add(mContext.getResources().getColor (R.color.track_line_56));
			colorList.add(mContext.getResources().getColor (R.color.track_line_57));
			colorList.add(mContext.getResources().getColor (R.color.track_line_57));
			colorList.add(mContext.getResources().getColor (R.color.track_line_58));
			colorList.add(mContext.getResources().getColor (R.color.track_line_58));
			colorList.add(mContext.getResources().getColor (R.color.track_line_59));
			colorList.add(mContext.getResources().getColor (R.color.track_line_59));
			colorList.add(mContext.getResources().getColor (R.color.track_line_60));
			colorList.add(mContext.getResources().getColor (R.color.track_line_60));

			colorList.add(mContext.getResources().getColor (R.color.track_line_61));
			colorList.add(mContext.getResources().getColor (R.color.track_line_61));
			colorList.add(mContext.getResources().getColor (R.color.track_line_62));
			colorList.add(mContext.getResources().getColor (R.color.track_line_62));
			colorList.add(mContext.getResources().getColor (R.color.track_line_63));
			colorList.add(mContext.getResources().getColor (R.color.track_line_63));
			colorList.add(mContext.getResources().getColor (R.color.track_line_64));
			colorList.add(mContext.getResources().getColor (R.color.track_line_64));
			colorList.add(mContext.getResources().getColor (R.color.track_line_65));
			colorList.add(mContext.getResources().getColor (R.color.track_line_65));
			colorList.add(mContext.getResources().getColor (R.color.track_line_66));
			colorList.add(mContext.getResources().getColor (R.color.track_line_66));
			colorList.add(mContext.getResources().getColor (R.color.track_line_67));
			colorList.add(mContext.getResources().getColor (R.color.track_line_67));
			colorList.add(mContext.getResources().getColor (R.color.track_line_68));
			colorList.add(mContext.getResources().getColor (R.color.track_line_68));
			colorList.add(mContext.getResources().getColor (R.color.track_line_69));
			colorList.add(mContext.getResources().getColor (R.color.track_line_69));
			colorList.add(mContext.getResources().getColor (R.color.track_line_70));
			colorList.add(mContext.getResources().getColor (R.color.track_line_70));

			colorList.add(mContext.getResources().getColor (R.color.track_line_71));
			colorList.add(mContext.getResources().getColor (R.color.track_line_71));
			colorList.add(mContext.getResources().getColor (R.color.track_line_72));
			colorList.add(mContext.getResources().getColor (R.color.track_line_72));
			colorList.add(mContext.getResources().getColor (R.color.track_line_73));//如果第四个颜色不添加，那么最后一段将显示上一段的颜色
			colorList.add(mContext.getResources().getColor (R.color.track_line_73));//如果第四个颜色不添加，那么最后一段将显示上一段的颜色

			colorList.add(mContext.getResources().getColor (R.color.track_line_73));
			colorList.add(mContext.getResources().getColor (R.color.track_line_73));
			colorList.add(mContext.getResources().getColor (R.color.track_line_72));
			colorList.add(mContext.getResources().getColor (R.color.track_line_72));
			colorList.add(mContext.getResources().getColor (R.color.track_line_71));
			colorList.add(mContext.getResources().getColor (R.color.track_line_71));
			colorList.add(mContext.getResources().getColor (R.color.track_line_70));
			colorList.add(mContext.getResources().getColor (R.color.track_line_70));
			colorList.add(mContext.getResources().getColor (R.color.track_line_69));
			colorList.add(mContext.getResources().getColor (R.color.track_line_69));
			colorList.add(mContext.getResources().getColor (R.color.track_line_68));
			colorList.add(mContext.getResources().getColor (R.color.track_line_68));
			colorList.add(mContext.getResources().getColor (R.color.track_line_67));
			colorList.add(mContext.getResources().getColor (R.color.track_line_67));
			colorList.add(mContext.getResources().getColor (R.color.track_line_66));
			colorList.add(mContext.getResources().getColor (R.color.track_line_66));
			colorList.add(mContext.getResources().getColor (R.color.track_line_65));
			colorList.add(mContext.getResources().getColor (R.color.track_line_65));
			colorList.add(mContext.getResources().getColor (R.color.track_line_64));
			colorList.add(mContext.getResources().getColor (R.color.track_line_64));

			colorList.add(mContext.getResources().getColor (R.color.track_line_63));
			colorList.add(mContext.getResources().getColor (R.color.track_line_63));
			colorList.add(mContext.getResources().getColor (R.color.track_line_62));
			colorList.add(mContext.getResources().getColor (R.color.track_line_62));
			colorList.add(mContext.getResources().getColor (R.color.track_line_61));
			colorList.add(mContext.getResources().getColor (R.color.track_line_61));
			colorList.add(mContext.getResources().getColor (R.color.track_line_60));
			colorList.add(mContext.getResources().getColor (R.color.track_line_60));
			colorList.add(mContext.getResources().getColor (R.color.track_line_59));
			colorList.add(mContext.getResources().getColor (R.color.track_line_59));
			colorList.add(mContext.getResources().getColor (R.color.track_line_58));
			colorList.add(mContext.getResources().getColor (R.color.track_line_58));
			colorList.add(mContext.getResources().getColor (R.color.track_line_57));
			colorList.add(mContext.getResources().getColor (R.color.track_line_57));
			colorList.add(mContext.getResources().getColor (R.color.track_line_56));
			colorList.add(mContext.getResources().getColor (R.color.track_line_56));
			colorList.add(mContext.getResources().getColor (R.color.track_line_55));
			colorList.add(mContext.getResources().getColor (R.color.track_line_55));
			colorList.add(mContext.getResources().getColor (R.color.track_line_54));
			colorList.add(mContext.getResources().getColor (R.color.track_line_54));

			colorList.add(mContext.getResources().getColor (R.color.track_line_53));
			colorList.add(mContext.getResources().getColor (R.color.track_line_53));
			colorList.add(mContext.getResources().getColor (R.color.track_line_52));
			colorList.add(mContext.getResources().getColor (R.color.track_line_52));
			colorList.add(mContext.getResources().getColor (R.color.track_line_51));
			colorList.add(mContext.getResources().getColor (R.color.track_line_51));
			colorList.add(mContext.getResources().getColor (R.color.track_line_50));
			colorList.add(mContext.getResources().getColor (R.color.track_line_50));
			colorList.add(mContext.getResources().getColor (R.color.track_line_49));
			colorList.add(mContext.getResources().getColor (R.color.track_line_49));
			colorList.add(mContext.getResources().getColor (R.color.track_line_48));
			colorList.add(mContext.getResources().getColor (R.color.track_line_48));
			colorList.add(mContext.getResources().getColor (R.color.track_line_47));
			colorList.add(mContext.getResources().getColor (R.color.track_line_47));
			colorList.add(mContext.getResources().getColor (R.color.track_line_46));
			colorList.add(mContext.getResources().getColor (R.color.track_line_46));
			colorList.add(mContext.getResources().getColor (R.color.track_line_45));
			colorList.add(mContext.getResources().getColor (R.color.track_line_45));
			colorList.add(mContext.getResources().getColor (R.color.track_line_44));
			colorList.add(mContext.getResources().getColor (R.color.track_line_44));

			colorList.add(mContext.getResources().getColor (R.color.track_line_43));
			colorList.add(mContext.getResources().getColor (R.color.track_line_43));
			colorList.add(mContext.getResources().getColor (R.color.track_line_42));
			colorList.add(mContext.getResources().getColor (R.color.track_line_42));
			colorList.add(mContext.getResources().getColor (R.color.track_line_41));
			colorList.add(mContext.getResources().getColor (R.color.track_line_41));
			colorList.add(mContext.getResources().getColor (R.color.track_line_40));
			colorList.add(mContext.getResources().getColor (R.color.track_line_40));
			colorList.add(mContext.getResources().getColor (R.color.track_line_39));
			colorList.add(mContext.getResources().getColor (R.color.track_line_39));
			colorList.add(mContext.getResources().getColor (R.color.track_line_38));
			colorList.add(mContext.getResources().getColor (R.color.track_line_38));
			colorList.add(mContext.getResources().getColor (R.color.track_line_37));
			colorList.add(mContext.getResources().getColor (R.color.track_line_37));
			colorList.add(mContext.getResources().getColor (R.color.track_line_36));
			colorList.add(mContext.getResources().getColor (R.color.track_line_36));
			colorList.add(mContext.getResources().getColor (R.color.track_line_35));
			colorList.add(mContext.getResources().getColor (R.color.track_line_35));
			colorList.add(mContext.getResources().getColor (R.color.track_line_34));
			colorList.add(mContext.getResources().getColor (R.color.track_line_34));

			colorList.add(mContext.getResources().getColor (R.color.track_line_33));
			colorList.add(mContext.getResources().getColor (R.color.track_line_33));
			colorList.add(mContext.getResources().getColor (R.color.track_line_32));
			colorList.add(mContext.getResources().getColor (R.color.track_line_32));
			colorList.add(mContext.getResources().getColor (R.color.track_line_31));
			colorList.add(mContext.getResources().getColor (R.color.track_line_31));
			colorList.add(mContext.getResources().getColor (R.color.track_line_30));
			colorList.add(mContext.getResources().getColor (R.color.track_line_30));
			colorList.add(mContext.getResources().getColor (R.color.track_line_29));
			colorList.add(mContext.getResources().getColor (R.color.track_line_29));
			colorList.add(mContext.getResources().getColor (R.color.track_line_28));
			colorList.add(mContext.getResources().getColor (R.color.track_line_28));
			colorList.add(mContext.getResources().getColor (R.color.track_line_27));
			colorList.add(mContext.getResources().getColor (R.color.track_line_27));
			colorList.add(mContext.getResources().getColor (R.color.track_line_26));
			colorList.add(mContext.getResources().getColor (R.color.track_line_26));
			colorList.add(mContext.getResources().getColor (R.color.track_line_25));
			colorList.add(mContext.getResources().getColor (R.color.track_line_25));
			colorList.add(mContext.getResources().getColor (R.color.track_line_24));
			colorList.add(mContext.getResources().getColor (R.color.track_line_24));

			colorList.add(mContext.getResources().getColor (R.color.track_line_23));
			colorList.add(mContext.getResources().getColor (R.color.track_line_23));
			colorList.add(mContext.getResources().getColor (R.color.track_line_22));
			colorList.add(mContext.getResources().getColor (R.color.track_line_22));
			colorList.add(mContext.getResources().getColor (R.color.track_line_21));
			colorList.add(mContext.getResources().getColor (R.color.track_line_21));
			colorList.add(mContext.getResources().getColor (R.color.track_line_20));
			colorList.add(mContext.getResources().getColor (R.color.track_line_20));
			colorList.add(mContext.getResources().getColor (R.color.track_line_19));
			colorList.add(mContext.getResources().getColor (R.color.track_line_19));
			colorList.add(mContext.getResources().getColor (R.color.track_line_18));
			colorList.add(mContext.getResources().getColor (R.color.track_line_18));
			colorList.add(mContext.getResources().getColor (R.color.track_line_17));
			colorList.add(mContext.getResources().getColor (R.color.track_line_17));
			colorList.add(mContext.getResources().getColor (R.color.track_line_16));
			colorList.add(mContext.getResources().getColor (R.color.track_line_16));
			colorList.add(mContext.getResources().getColor (R.color.track_line_15));
			colorList.add(mContext.getResources().getColor (R.color.track_line_15));
			colorList.add(mContext.getResources().getColor (R.color.track_line_14));
			colorList.add(mContext.getResources().getColor (R.color.track_line_14));

			colorList.add(mContext.getResources().getColor (R.color.track_line_13));
			colorList.add(mContext.getResources().getColor (R.color.track_line_13));
			colorList.add(mContext.getResources().getColor (R.color.track_line_12));
			colorList.add(mContext.getResources().getColor (R.color.track_line_12));
			colorList.add(mContext.getResources().getColor (R.color.track_line_11));
			colorList.add(mContext.getResources().getColor (R.color.track_line_11));
			colorList.add(mContext.getResources().getColor (R.color.track_line_10));
			colorList.add(mContext.getResources().getColor (R.color.track_line_10));
			colorList.add(mContext.getResources().getColor (R.color.track_line_9));
			colorList.add(mContext.getResources().getColor (R.color.track_line_9));
			colorList.add(mContext.getResources().getColor (R.color.track_line_8));
			colorList.add(mContext.getResources().getColor (R.color.track_line_8));
			colorList.add(mContext.getResources().getColor (R.color.track_line_7));
			colorList.add(mContext.getResources().getColor (R.color.track_line_7));
			colorList.add(mContext.getResources().getColor (R.color.track_line_6));
			colorList.add(mContext.getResources().getColor (R.color.track_line_6));
			colorList.add(mContext.getResources().getColor (R.color.track_line_5));
			colorList.add(mContext.getResources().getColor (R.color.track_line_5));
			colorList.add(mContext.getResources().getColor (R.color.track_line_4));
			colorList.add(mContext.getResources().getColor (R.color.track_line_4));

			colorList.add(mContext.getResources().getColor (R.color.track_line_3));
			colorList.add(mContext.getResources().getColor (R.color.track_line_3));
			colorList.add(mContext.getResources().getColor (R.color.track_line_2));
			colorList.add(mContext.getResources().getColor (R.color.track_line_2));
			colorList.add(mContext.getResources().getColor (R.color.track_line_1));//如果第四个颜色不添加，那么最后一段将显示上一段的颜色
			colorList.add(mContext.getResources().getColor (R.color.track_line_1));//如果第四个颜色不添加，那么最后一段将显示上一段的颜色
		}

		return colorList;
	}
}
